setwd("D:/experiment/Conference Paper/ECML/ECML2022")
rm(list = ls())
library(MASS)

#("F:/experiment/R/exercise/kernel_xy.R")

##############################################################################
#
#            sigma : gaussian kernel parameter
#            gamma : maximum coefficient
#            lambda: regularized  parameter
#            eta   : gradient descent step size
#            B     : budget 
#            loss  : hinge loss 
#            SV    : set of support vector 
#
##############################################################################
d_index <- 1

dpath          <- file.path("D:/experiment/online learning dataset/regression/") 

Dataset        <- c("elevators_all","bank_all","ailerons_all","N-TomsHardware")   

savepath1      <- paste0("D:/experiment/Conference Paper/ECML/ECML2022/ECML2022 Result/",
                         paste0("RF-OKS-absolute",Dataset[d_index],".txt"))
savepath2      <- paste0("D:/experiment/Conference Paper/ECML/ECML2022/ECML2022 Result/",
                         paste0("RF-OKS-absolute-all-",Dataset[d_index],".txt"))

traindatapath    <- file.path(dpath, paste0(Dataset[d_index], ".train"))
traindatamatrix  <- as.matrix(read.table(traindatapath))
trdata           <- traindatamatrix[ ,-1]
ylabel           <- traindatamatrix[ ,1]                                             

length_tr  <- nrow(trdata)                                               
feature_tr <- ncol(trdata)

p_setting <- list(
  delta   = 0.05,
  eta     = 1/sqrt(length_tr),
  lambda  = 5/sqrt(length_tr),
  d      = feature_tr,
  D      = 530
)
x         <- seq(-2,3,1)
sigma     <- 2^(x)
len_sigma <- length(sigma)

p_setting$delta  <- (len_sigma/length_tr)^(1/3)
p_setting$eta    <- sqrt(2*(1-p_setting$delta)*log(len_sigma)/(len_sigma*length_tr))
p_setting$lambda <- 5*sqrt(p_setting$delta)/sqrt(len_sigma*length_tr)

p1 <- (1-p_setting$delta)
p2 <- p_setting$delta/len_sigma

reptimes <- 10
runtime  <- c(rep(0, reptimes))
errorrate<- c(rep(0, reptimes))
all_p    <- matrix(0,nrow = reptimes, ncol = len_sigma)
all_error<- matrix(0,nrow = reptimes, ncol = len_sigma)

all_infor<- matrix(0,nrow = reptimes, ncol = 3*len_sigma)

for(re in 1:reptimes)
{
  order    <- sample(1:length_tr,length_tr,replace = F)   
  u       <- mvrnorm(p_setting$D,rep(0,p_setting$d),diag(p_setting$d))   # w--->D*d
  
  error    <- c(rep(0, len_sigma))
  L        <- c(rep(0, len_sigma))
  k        <- c(rep(0, len_sigma))
  nabla    <- c(rep(0, len_sigma))
  p        <- c(rep(1/len_sigma,len_sigma))
  
  t1       <- proc.time()  #proc.time()
  W        <- matrix(0,nrow=len_sigma, ncol=2*p_setting$D)
  zx       <- c(rep(0, 2*p_setting$D))
  
  for (i in 1:length_tr)
  {
    err    <- 0
    It     <- sample(1:len_sigma, 1, replace = T, prob=p)
    tem    <- u%*%trdata[order[i],]
    
    tem    <- tem/sigma[It]
    coszx  <- cos(tem)/sqrt(p_setting$D)
    sinzx  <- sin(tem)/sqrt(p_setting$D)
    
    zx     <- c(coszx,sinzx)
    fx     <- crossprod(W[It,],zx)
    fx     <- fx[1,1]

    loss <- abs(fx-ylabel[order[i]])
    
    tilde_nabla <- sign(fx-ylabel[order[i]])/p[It]
    W[It,]      <- W[It,] - p_setting$lambda*tilde_nabla*zx
    
    error[It] <- error[It] + loss
    L[It]     <- L[It] + loss/p[It]

    p = p1*exp(-1*p_setting$eta*L)/sum(exp(-1*p_setting$eta*L)) + p2
  }
  t2 <- proc.time()
  runtime[re]    <- (t2 - t1)[3]
  errorrate[re]  <- sum(error)/length_tr
  all_error[re,] <- error
  all_p[re,]     <- p
}

save_result <- list(
  note     = c("the next term are:alg_name--dataname--sv_num--run_time--err_num--tot_run_time--ave_run_time--ave_err_rate--sd_time--sd_error"),
  alg_name = c("RF-OKS-absolute"),
  dataname = paste0(Dataset[d_index], ".train"),
  run_time = as.character(runtime),
  err_num  = as.character(errorrate), 
  tot_run_time = sum(runtime),
  ave_run_time = sum(runtime)/reptimes,
  ave_err_rate = sum(errorrate)/reptimes,
  sd_time  <- sd(runtime),
  sd_err    <-sd(errorrate)
)

all_infor[,(len_sigma+1):(2*len_sigma)] = all_p[,1:len_sigma]
all_infor[,(2*len_sigma+1):(3*len_sigma)] = all_error[,1:len_sigma]

write.table(save_result,file=savepath1,row.names =TRUE, col.names =FALSE, quote = T) 
write.table(all_infor,file=savepath2,row.names =TRUE, col.names =FALSE, quote = T) 

sprintf("the candidate kernel parameter are :")
sprintf("%.5f", sigma)
sprintf("the number of sample is %d", length_tr)
sprintf("total training time is %.4f in dataset", sum(runtime))
sprintf("average training time is %.5f in dataset", sum(runtime)/reptimes)
sprintf("the average error rate is %f", sum(errorrate)/reptimes)
sprintf("standard deviation of run_time is %.5f in dataset", sd(runtime))
sprintf("standard deviation of error is %.5f in dataset", sd(errorrate))
sprintf("average per-round prediction time is %.5f in dataset", 
        sum(runtime)/reptimes/length_tr*10^5)
