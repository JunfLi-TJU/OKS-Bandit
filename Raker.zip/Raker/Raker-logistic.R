setwd("D:/experiment/Conference Paper/ECML/ECML2022")
rm(list = ls())
library(MASS)
#source("F:/experiment/BasicFunction/ORF.R")

dpath          <- file.path("D:/experiment/online learning dataset/binary C")  

d_index        <- 3
Dataset        <- c("w8a", "a9a", "phishing","magic04-N","ijcnn1","w7a", "SUSY20000-N", 
                   "cod-rna","cod-rna_all","german","spambase","mnist12_all","mushrooms","svmguide1_all",
                   "image_all","magic04","a9a_all","madelon_all","svmguide3_all",
                   "SUSY100000","w8a","waveform","Musk")

savepath1      <- paste0("D:/experiment/Conference Paper/ECML/ECML2022/ECML2022 Result/",
                         paste0("Raker-logistic-",Dataset[d_index],".txt"))
savepath2      <- paste0("D:/experiment/Conference Paper/ECML/ECML2022/ECML2022 Result/",
                         paste0("Raker-logistic-all-",Dataset[d_index],".txt"))

traindatapath    <- file.path(dpath, paste0(Dataset[d_index], ".train"))

traindatamatrix <- as.matrix(read.table(traindatapath))
trdata  <- traindatamatrix[ ,-1]
ylabel  <- traindatamatrix[ ,1]                                           

length_tr  <- nrow(trdata)                                               
feature_tr <- ncol(trdata)

p_setting <- list(
  d      = feature_tr,
  D      = 70
)

x         <-seq(-2,3,1)
sigma     <- 2^(x)
len_sigma <- length(sigma)


reptimes  <- 10
runtime   <- c(rep(0, reptimes))
errorrate <- c(rep(0, reptimes))
cum_Loss  <- c(rep(0, reptimes))
all_infor <- matrix(0,nrow = reptimes, ncol = 3*len_sigma)
all_p     <- matrix(0,nrow = reptimes, ncol = len_sigma)

for(re in 1:reptimes)
{
  order   <- sample(1:length_tr,length_tr,replace = F)   #dis
  u       <- mvrnorm(p_setting$D,rep(0,p_setting$d),diag(p_setting$d))   # w--->D*d
  error   <- 0
  p       <- c(rep(1/len_sigma,len_sigma))
  L       <- c(rep(0,len_sigma))
  nabla   <- 0
  eta     <- 5/sqrt(length_tr)
  mu      <- 0.005
  lmax    <- 2 ## lmax is used to scale the loss, since raker require the loss lying in [-1,1]
  W       <- matrix(0,nrow=len_sigma, ncol=2*p_setting$D)
  zx      <- c(rep(0, 2*p_setting$D))
  t1      <- proc.time()  #proc.time()
  
  for (i in 1:length_tr)
  {
    hatp <- 0
    #    eta    <- 2/sqrt(i)
    tem    <- u%*%trdata[order[i],]
    for(j in 1:len_sigma)
    {
      tem    <- tem/sigma[j]
      coszx  <- cos(tem)/sqrt(p_setting$D)
      sinzx  <- sin(tem)/sqrt(p_setting$D)
      zx     <- c(coszx,sinzx)
      sum    <- crossprod(W[j,],zx)[1,1]
      hatp   <- hatp+p[j]*sum
      ex     <- exp(-ylabel[order[i]]*sum)
      nabla  <- ex/(1+ex)
      L[j]   <- L[j] + (log(1+ex)+mu*crossprod(W[j,],W[j,]))/lmax
      W[j,]  <- (1-2*eta*mu)*W[j,] +eta*nabla*ylabel[order[i]]*zx
    }
    hatyt <- 1
    if(hatp< 0)
      hatyt <- -1
    if(hatyt != ylabel[order[i]])
      error <- error +1
    ex      <- exp(-ylabel[order[i]]*hatp)
    p = exp(-1*eta*L)/sum(exp(-1*eta*L))
  }
  t2 <- proc.time()
  runtime[re]   <- (t2 - t1)[3]
  errorrate[re] <- error/length_tr
  all_p[re,]    <- p
}

save_result <- list(
  note     = c(" the next term are:alg_name--dataname--sam_num--sv_num--run_time--err_num--tot_run_time--ave_run_time--ave_err_rate--sd_time--sd_error"),
  alg_name = c("Raker-logistic"),
  dataname = paste0(Dataset[d_index], ".train"),
  sam_num  = length_tr,
  run_time = as.character(runtime),
  err_num  = as.character(errorrate), 
  tot_run_time = sum(runtime),
  ave_run_time = sum(runtime)/reptimes,
  ave_err_rate = sum(errorrate)/reptimes,
  sd_time  <- sd(runtime),
  sd_err    <-sd(errorrate)
)

write.table(save_result,file=savepath1,row.names =TRUE, col.names =FALSE, quote = T) 
#write.table(all_infor,file=savepath2,row.names =TRUE, col.names =FALSE, quote = T) 

sprintf("the candidate kernel parameter are :")
sprintf("%.5f", sigma)
sprintf("the number of sample is %d", length_tr)
sprintf("total training time is %.4f in dataset", sum(runtime))
sprintf("average training time is %.5f in dataset", sum(runtime)/reptimes)
sprintf("the average MR is %f", sum(errorrate)/reptimes)
sprintf("standard deviation of run_time is %.5f in dataset", sd(runtime))
sprintf("standard deviation of error is %.5f in dataset", sd(errorrate))
sprintf("average per-round prediction time is %.5f in dataset", 
        sum(runtime)/reptimes/length_tr*10^5)